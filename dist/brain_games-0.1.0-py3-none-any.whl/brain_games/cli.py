import prompt


def welcome_user():
	print('May I have your name?')
	name = input()
	print('Hello, ' + name)

